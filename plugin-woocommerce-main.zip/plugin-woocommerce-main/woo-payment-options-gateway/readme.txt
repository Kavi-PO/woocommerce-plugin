=== Payment Plugins for Stripe WooCommerce ===
Contributors: paymentoptions
Tags: paymentoptions, credit card, debit card, payment method 
Requires at least: 3.0.1
Tested up to: 5.9
Requires PHP: 5.6
Stable tag: 1.0
Copyright: Payment Plugins
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

= Features =
- Enable/disable plugin functionality
- Title, description options, It will be shown on the configuration checkout page.
- Sandbox Mode options, Allows merchants to test a payment processor without having to pay the transaction they have submitted,
- Configure the Merchant ID, API URL and provided by Payment Options
- Auto Capture functionality, Customers can use this setting to capture all authorized payments automatically.

